/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server;

public class testMain {
    public static void main(String[] args) {
    }
}