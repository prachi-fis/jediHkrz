/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server.services;

import java.io.File;
import java.io.FileOutputStream;

public class FileWriter {
    public void writeFile(byte[] bytes, String path) {
        try {
            FileOutputStream fos = new FileOutputStream(new File(path));
            fos.write(bytes);
            fos.close();
        } catch (Exception e) {

        }
    }
}