/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server.responses;

public class RegisterResponse {
    private String status;
    private String faceId;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFaceId() {
        return faceId;
    }

    public void setFaceId(String faceId) {
        this.faceId = faceId;
    }
}