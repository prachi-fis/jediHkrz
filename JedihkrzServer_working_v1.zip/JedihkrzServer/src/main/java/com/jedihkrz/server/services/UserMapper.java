/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server.services;

import com.jedihkrz.server.models.Account;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserMapper {
    private static UserMapper userMapper;
    private static Map<String, Account> userMap = new HashMap<>();

    static private final Logger log = LoggerFactory.getLogger(UserMapper.class);

    private UserMapper() {
    }

    public static UserMapper get() {
        if (userMapper == null) {
            userMapper = new UserMapper();
        }
        return userMapper;
    }

    public void addUser(String userName, String faceId) {
        if (!userMap.containsKey(userName)) {
            AccountReader accountReader = new AccountReader();
            try {
                List<Account> accountList = accountReader.getAccountsFromJson();

                for (int i = 0; i < accountList.size(); i++) {
                    if (accountList.get(i).getAccountHolder().equals(userName)) {
                        Account currentAccount = accountList.get(i);
                        currentAccount.setFaceId(faceId);
                        userMap.put(userName, currentAccount);
                    }
                }
            } catch (Exception e) {
                log.warn("User registration failed. " + e.getMessage());
            }
        }
    }

    public Account getUserAccount(String userName) {
        if (userMap.containsKey(userName)) {
            return userMap.get(userName);
        } else {
            log.warn("User not found.");
            return null;
        }
    }
}