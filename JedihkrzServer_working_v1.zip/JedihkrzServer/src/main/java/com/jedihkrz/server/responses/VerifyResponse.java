/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server.responses;

public class VerifyResponse {
    private boolean isIdentical;
    private double confidence;

    public boolean getIsIdentical() {
        return isIdentical;
    }

    public void setIsIdentical(boolean identical) {
        isIdentical = identical;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }
}