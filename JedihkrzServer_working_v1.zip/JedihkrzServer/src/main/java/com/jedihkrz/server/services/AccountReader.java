/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server.services;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.jedihkrz.server.models.Account;
import com.jedihkrz.server.models.AccountList;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;

public class AccountReader {
    public List<Account> getAccountsFromJson() throws FileNotFoundException {
        Gson gson = new Gson();

        // Reads the Accounts.json file from Jboss server location on the deployment server
        JsonReader reader = new JsonReader(new FileReader("/usr/local/jboss6/standalone/configuration/accounts/Accounts.json"));
        AccountList accountList = gson.fromJson(reader, AccountList.class);
        return accountList.getAccountList();
    }
}