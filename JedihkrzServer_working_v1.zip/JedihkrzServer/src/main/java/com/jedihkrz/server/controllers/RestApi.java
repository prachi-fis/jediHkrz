/*
 * © 2017 Team FISinnovatein48 #jediHKRZ
 */
package com.jedihkrz.server.controllers;

import com.jedihkrz.server.JsonTransformer;
import com.jedihkrz.server.models.Account;
import com.jedihkrz.server.responses.RegisterResponse;
import com.jedihkrz.server.services.DetectService;
import com.jedihkrz.server.services.UserMapper;
import com.jedihkrz.server.services.VerifyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import spark.Spark;
import spark.servlet.SparkApplication;

public class RestApi implements SparkApplication {

    static private final Logger log = LoggerFactory.getLogger(RestApi.class);

    public void init() {

        Spark.post("/getaccount", (request, response) -> {
            String userId = request.queryParams("user");
            boolean authenticated = false;

            DetectService detectService = new DetectService();
            String testFaceId = detectService.detect(request.bodyAsBytes());    // Gets the FaceId of the image

            Account compareAccount = UserMapper.get().getUserAccount(userId);
            if (compareAccount != null) {
                String userFaceId = compareAccount.getFaceId();
                VerifyService verifyService = new VerifyService();
                if (verifyService.verify(userFaceId, testFaceId)) {             // Verifies that the image is associated with a registered user
                    authenticated = true;
                }

                if (authenticated) {
                    log.info("Account details displayed for given user.");
                }
            } else {
                log.warn("User authentication failed. Try again.");
            }

            return (authenticated ? compareAccount : null);
        }, new JsonTransformer());

        Spark.post("/register", (request, response) -> {
            byte[] imageAsByteArray = request.bodyAsBytes();

            DetectService detectService = new DetectService();
            String faceId = detectService.detect(imageAsByteArray);

            String userId = request.queryParams("user");
            UserMapper.get().addUser(userId, faceId);

            RegisterResponse registerResponse = new RegisterResponse();

            log.info("User Registration Successful!");

            registerResponse.setStatus("User Registration Successful!");
            return registerResponse.getStatus();
        }, new JsonTransformer());
    }
}